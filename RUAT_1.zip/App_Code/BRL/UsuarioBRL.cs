﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BRL { 
public class UsuarioBRL
{
    public UsuarioBRL()
    {
       
    }

        public static Usuario GetUsuarioByUsername (string username)
        {
            if (string.IsNullOrEmpty(username))

                throw new ArgumentException("El username no puede  ser nulo o vacio");

            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();

            UsuarioDS.UsuarioDataTable table = adapter.GetUsuarioByUsername(username);


            Usuario result = null;

            if (table.Rows.Count == 1)
            {
                UsuarioDS.UsuarioRow row = table[0];

                result = new Usuario()
                {
                    Fullname = row.fullname,
                    Password = row.password,
                    UserId   = row.userId,
                    Username = row.username

                };
            }

                return result;

        }




        private static void ValidarObjetoUsuario(Usuario obj)
        {
            if (obj == null)

                throw new ArgumentException("El objeto no puede ser nulo");

            if (string.IsNullOrEmpty(obj.Fullname))

                throw new ArgumentException("FullName no puede ser nulo o vacio");


            if (string.IsNullOrEmpty(obj.Username))

                throw new ArgumentException("UserName no puede ser nulo o vacio");


            if (string.IsNullOrEmpty(obj.Password))

                throw new ArgumentException("Password no puede ser nulo o vacio");



           




        }










        public static int InsertarUsuario(Usuario obj)
        {





            ValidarObjetoUsuario(obj);

            int? usuarioId = null;
            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();
            adapter.Insert(obj.Fullname, obj.Username, obj.Password,  ref usuarioId);

            return usuarioId.Value;

        }


        public static void UpdateUsuario(Usuario obj)
        {

            ValidarObjetoUsuario(obj);

            if (obj.UserId < 0)

                throw new ArgumentException("El objeto no puede ser negativo");


            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();

            adapter.Update(obj.UserId, obj.Fullname, obj.Username, obj.Password);




        }


        public static void DeleteUsuario(int usuarioId)
        {
            if (usuarioId <= 0)
                throw new ArithmeticException("El Usuario Id no puede ser menor o igual a cero");
            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();
            adapter.Delete(usuarioId);
        }

        public static Usuario GetUsuarioById(int usuarioId)
        {
            if (usuarioId <= 0)

                throw new ArgumentException("Usuario id no puede ser menor  o igual que cero");

            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();
            UsuarioDS.UsuarioDataTable table = adapter.GetUsuarioById(usuarioId);


            UsuarioDS.UsuarioRow row = table[0];

            Usuario result = GetUsuarioFromRow(row);

            return result;
        }


        public static List<Usuario> GetUsuarios()
        {


            UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();
            UsuarioDS.UsuarioDataTable table = adapter.GetUsuarios();


            List<Usuario> list = new List<Usuario>();
            foreach (var row in table)

            {
                Usuario obj = GetUsuarioFromRow(row);

                list.Add(obj);
            }



            return list;
        }


        public static List<Usuario> GetUsuariosBySearch(string searchTerm)
        {

            if (searchTerm == null)
                searchTerm = "";
          UsuarioDSTableAdapters.UsuarioTableAdapter adapter = new UsuarioDSTableAdapters.UsuarioTableAdapter();
            UsuarioDS.UsuarioDataTable table = adapter.GetUsuarioBySearch(searchTerm);


            List<Usuario> list = new List<Usuario>();
            foreach (var row in table)

            {
                Usuario obj = GetUsuarioFromRow(row);

                list.Add(obj);
            }



            return list;
        }


        private static Usuario GetUsuarioFromRow(UsuarioDS.UsuarioRow row)

        {
            return new Usuario()
            {
                UserId = row.userId,
                Fullname = row.fullname,
                Username = row.username,
                Password = row.password,
               

            };
        }



    }
}