﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Model

{
    public class VehiculoBRL
    {
        public VehiculoBRL()
        {




        }

        private static void ValidarObjetoVehiculo(Vehiculo obj)
        {
            if (obj == null)

                throw new ArgumentException("El objeto no puede ser nulo");

            if (string.IsNullOrEmpty(obj.Placa))

                throw new ArgumentException("Placa no puede ser nulo o vacio");


            if (string.IsNullOrEmpty(obj.Marca))

                throw new ArgumentException("Marca no puede ser nulo o vacio");


            if (string.IsNullOrEmpty(obj.Modelo))

                throw new ArgumentException("Modelo no puede ser nulo o vacio");



            if (string.IsNullOrEmpty(obj.Color))

                throw new ArgumentException("Color no puede ser nulo o vacio");



           




            if (string.IsNullOrEmpty(obj.Observaciones))

                throw new ArgumentException("Observaciones no puede ser nulo o vacio");

            if (string.IsNullOrEmpty(obj.Clase))

                throw new ArgumentException("Clase no puede ser nulo o vacio");


            


            if (obj.PersonaId <= 0)

                throw new ArgumentException("PersonaId no puede ser nulo o vacio");

            if (obj.CodigoExterno<= 0)

                throw new ArgumentException("Codigo no puede ser nulo o vacio");
            



        }
        public static int InsertarVehiculo(Vehiculo obj)
        {





            ValidarObjetoVehiculo(obj);

            int? vehiculoId = null;
            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();
            adapter.Insert(obj.Placa,obj.Color,obj.Marca,obj.Clase,obj.Modelo,obj.Observaciones,obj.PersonaId,obj.CodigoExterno, ref vehiculoId);

            return vehiculoId.Value;

        }


        public static void UpdateVehiculo(Vehiculo obj)
        {

            ValidarObjetoVehiculo(obj);

            if (obj.AutoId < 0)

                throw new ArgumentException("El objeto no puede ser negativo");


            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();

            adapter.Update(obj.AutoId,obj.Placa, obj.Color, obj.Marca, obj.Clase, obj.Modelo, obj.Observaciones, obj.PersonaId,obj.CodigoExterno);




        }


        public static void DeleteVehiculo(int vehiculoId)
        {
            if (vehiculoId <= 0)
                throw new ArithmeticException("El vehiculo Id no puede ser menor o igual a cero");
            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();
            adapter.Delete(vehiculoId);
        }

        public static Vehiculo GetVehiculoById(int vehiculoId)
        {
            if (vehiculoId <= 0)

                throw new ArgumentException("Vehiculo id no puede ser menor  o igual que cero");

            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();
            VehiculoDS.VehiculosDataTable table = adapter.GetVehiculosById(vehiculoId);


            VehiculoDS.VehiculosRow row = table[0];

            Vehiculo result = GetVehiculoFromRow(row);

            return result;
        }


        public static List<Vehiculo> GetVehiculos()
        {


            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();
            VehiculoDS.VehiculosDataTable table = adapter.GetVehiculos();


            List<Vehiculo> list = new List<Vehiculo>();
            foreach (var row in table)

            {
                Vehiculo obj = GetVehiculoFromRow(row);

                list.Add(obj);
            }



            return list;
        }


        public static List<Vehiculo> GetVehiculosBySearch(string searchTerm)
        {

            if (searchTerm == null)
                searchTerm = "";
            VehiculoDSTableAdapters.VehiculosTableAdapter adapter = new VehiculoDSTableAdapters.VehiculosTableAdapter();
            VehiculoDS.VehiculosDataTable table = adapter.GetVehiculosBySearch(searchTerm);


            List<Vehiculo> list = new List<Vehiculo>();
            foreach (var row in table)

            {
                Vehiculo obj = GetVehiculoFromRow(row);

                list.Add(obj);
            }



            return list;
        }


        private static Vehiculo GetVehiculoFromRow(VehiculoDS.VehiculosRow row)

        {
            return new Vehiculo()
            {
                AutoId = row.AutoId,
                Placa  = row.Placa,  
                Clase = row.Clase,
                Modelo = row.Modelo,
                Color = row.Color,
                Observaciones = row.Observaciones,
                Marca = row.Marca,
               
                PersonaId = row.PersonaId
                
               


               

            };
        }
       


    }

}