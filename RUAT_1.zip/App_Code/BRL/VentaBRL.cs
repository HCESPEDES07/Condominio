﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
namespace BRL
{
    /// <summary>
    /// Descripción breve de ActaBRL
    /// </summary>
    public class VentaBRL
    {
        public VentaBRL()
        {

        }
        public static List<Venta> GetVentas()
        {
            VentaDsTableAdapters.VentaTableAdapter adapter = new VentaDsTableAdapters.VentaTableAdapter();


            VentaDs.VentaDataTable table = adapter.GetVentas();


            List<Venta> list = new List<Venta>();
            foreach (var row in table)
            {
               

                list.Add(GetVentaFromRow(row));

            }
            return list;
        }

        public static int InsertVenta(Venta venta, List<DetalleVenta> detalle)
        {
            if (venta == null)
                throw new ArgumentException("El objeto no puede ser nulo");

            if (detalle == null)
                throw new ArgumentException("El detalle no puede ser nulo");

            if (detalle.Count == 0)
                throw new ArgumentException("Debe haber al menos una mascota");

            if (venta.PersonaId <= 0)
                throw new ArgumentException("una persona");

            if(string.IsNullOrEmpty(venta.RazonSocial))
                throw new ArgumentException("La Razon Social no puede ser nulo o vacio");

            if (string.IsNullOrEmpty(venta.Nit))
                throw new ArgumentException("El Nit no puede ser nulo o vacio");


            if (venta.Total <= 0)
                throw new ArgumentException("El total tiene que ser mayor");
            if (venta.UsuarioId <= 0)
                throw new ArgumentException("una persona");




            Type typeInt = typeof(int);
            Type typeVarchar = typeof(string);
            Type typeDecimal = typeof(decimal);

            DataTable tbl = new DataTable();
            tbl.Columns.Add("VentaId", typeInt);
            tbl.Columns.Add("VehiculoId", typeInt);
            tbl.Columns.Add("Cantidad", typeInt);
            tbl.Columns.Add("PrecioUnitario", typeDecimal);
            tbl.Columns.Add("Subtotal", typeDecimal);
           


            foreach (var item in detalle)
            {
                DataRow row = tbl.NewRow();
                row["VentaId"] = item.ventaId;
                row["VehiculoId"] = item.vehiculoId;
                row["Cantidad"] = item.cantidad;
                row["PrecioUnitario"] = item.precioUnitario;
                row["SubTotal"] = item.Subtotal;

                tbl.Rows.Add(row);



            }

            int? ventaId = 0;
            VentaDsTableAdapters.VentaTableAdapter adapter = new VentaDsTableAdapters.VentaTableAdapter();
            adapter.InsertVenta(venta.RazonSocial,venta.Nit, venta.Total, venta.PersonaId,venta.UsuarioId, tbl, ref ventaId);
           
            return ventaId.Value;

        }




        private static Venta GetVentaFromRow(VentaDs.VentaRow row)
        {
            return new Venta()
            {
                VentaId = row.VentaId,
                RazonSocial = row.RazonSocial,
            
                PersonaId = row.PersonaId,
                Total = row.Total,
                UsuarioId =    row.UsuarioId,
                Fecha = row.Fecha
               

            };


        }

    }
}