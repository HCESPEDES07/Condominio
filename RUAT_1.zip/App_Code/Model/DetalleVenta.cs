﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Model
{


public class DetalleVenta
{
        public int ventaId { get; set; }
        public int vehiculoId { get; set; }
        public int cantidad { get; set; }
        public decimal precioUnitario { get; set; }
        public decimal Subtotal { get; set; }
        

        public DetalleVenta()
    {
      
    }

    }
}