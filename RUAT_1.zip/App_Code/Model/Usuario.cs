﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Usuario
/// </summary>
/// 
namespace Model { 
public class Usuario
{
    public int UserId { get; set; }
    private string _username;


    public string Username
    {
        get { return _username; }
        set { _username = value; }

    }

    public string Fullname { get; set; }
    public string Password { get; set; }


    public Usuario()
    {
      
    }
}
}
