﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Model
{
    public class Vehiculo
{


        public int    AutoId { get; set; }
        public string Placa { get; set; }
        public string Color { get; set; }
        public string Marca { get; set; }
        public string Clase { get; set; }
        public string Modelo { get; set; }
     
        public string Observaciones { get; set; }
        public int    PersonaId { get; set; }
        public int    CodigoExterno { get; set; }
        




        public Vehiculo()
        {
            
        }
}

}