﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Acta
/// </summary>

namespace Model
{ 
public class Venta
{

        public int VentaId { get; set; }
        public int PersonaId { get; set; }
        public int UsuarioId { get; set; }
        public decimal Total { get; set; }
        public string RazonSocial { get; set; }
        public string Nit { get; set; }
        
        public DateTime Fecha { get; set; }

        public Venta()
    {
       
    }
}
}