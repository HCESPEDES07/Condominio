﻿using BRL;
using Model;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Usuario_FormularioUsuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
            return;


        string strId = Request.QueryString["id"];
        int usuarioId = 0;
        if (!string.IsNullOrEmpty(strId))
        {

            try
            {
               usuarioId = Convert.ToInt32(strId);
                if (usuarioId < 0)
                    usuarioId = 0;
            }
            catch (Exception ex)
            {

            }


        }


        UsuarioIdHiddenField.Value = usuarioId.ToString();


        if (usuarioId > 0)

        {

            CargarUsuario(usuarioId);

        }

    }

    private void CargarUsuario(int usuarioId)
    {
        try
        {
            Titulo.Text = "Editar Usuario";
            Usuario obj = UsuarioBRL.GetUsuarioById(usuarioId);

            FullnameTextBox.Text = obj.Fullname;
            UserNameTextBox.Text = obj.Username;
            PasswordTextBox.Text = obj.Password;
         

        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al obetener los datos de la mascota seleccionada: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-3 mb-2";
            return;
        }
    }

    protected void BtnGuardar_Click(object sender, EventArgs e)
    {
        try
        {





           
            int usuarioId = Convert.ToInt32(UsuarioIdHiddenField.Value);
            Usuario obj = new Usuario();

            obj.Fullname = FullnameTextBox.Text.Trim();
            obj.Username = UserNameTextBox.Text.Trim();
            obj.Password = Utilities.Hash( PasswordTextBox.Text.Trim());
     
            obj.UserId = usuarioId;

            if (usuarioId == 0)

                UsuarioBRL.InsertarUsuario(obj);

            else
                UsuarioBRL.UpdateUsuario(obj);
        }

        catch (Exception ex)
        {


            MsgLabel.Text = "Ocurrio un error al guardar los datos del Usuario seleccionado: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-3 mb-2";
            return;

        }

        Response.Redirect("ListaUsuarios.aspx");

    }
}