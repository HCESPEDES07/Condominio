﻿using BRL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Usuario_ListaUsuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (IsPostBack)

            return;

        CargarLista();



    }
    private void CargarLista()
    {
        MsgPanel.Visible = false;
        try
        {
            GridUsuarios.DataSource = UsuarioBRL.GetUsuarios();
            GridUsuarios.DataBind();
        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al cargar la lista de usuarios: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
            return;
        }

    }

    protected void GridUsuarios_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        MsgPanel.Visible = false;
        int usuarioId = 0;
        try
        {
            usuarioId = Convert.ToInt32(e.CommandArgument);
        }
        catch
        {
            MsgLabel.Text = "NO se pudo obtener el identificador del usuario";
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

            return;
        }

        if (usuarioId <= 0)
            return;



        if (e.CommandName == "Editar")
        {
            Response.Redirect("FormularioUsuario.aspx?id=" + usuarioId.ToString());
        }
        if (e.CommandName == "Eliminar")
        {
            try
            {

               UsuarioBRL.DeleteUsuario(usuarioId);

                CargarLista();


                MsgLabel.Text = "El usuario fue eliminado correctamente";
                MsgPanel.Visible = true;
                MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

            }
            catch (Exception ex)
            {
                MsgLabel.Text = "Ocurrio un error al eliminar el usuario seleccionado: " + ex.Message;
                MsgPanel.Visible = true;
                MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
                return;
            }
        }


    }
    protected void SearchButton_Click(object sender, EventArgs e)
    {

        MsgPanel.Visible = false;
        try
        {
            GridUsuarios.DataSource = UsuarioBRL.GetUsuariosBySearch(SearchTextBox.Text.Trim());
            GridUsuarios.DataBind();
        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al cargar la lista de vehiculos: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
            return;
        }
    }


}
