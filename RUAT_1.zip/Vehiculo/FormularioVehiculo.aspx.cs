﻿using Model;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vehiculo_Formulario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
            return;


        string strId = Request.QueryString["id"];
        int vehiculoId = 0;
        if (!string.IsNullOrEmpty(strId))
        {

            try
            {
                vehiculoId = Convert.ToInt32(strId);
                if (vehiculoId < 0)
                    vehiculoId = 0;
            }
            catch (Exception ex)
            {

            }


        }

        
       
        VehiculoIdHiddenField.Value = vehiculoId.ToString();


        if (vehiculoId > 0)

        {

            CargarMascota(vehiculoId);

        }

    }

    private void CargarMascota(int vehiculoId)
    {
        try
        {
            Titulo.Text = "Editar Vehiculo";
            Vehiculo obj = VehiculoBRL.GetVehiculoById(vehiculoId);

            PlacaTextBox.Text = obj.Placa;
            ColorTextBox.Text = obj.Color;
            MarcaTextBox.Text = obj.Marca;
            ClaseTextBox.Text = obj.Clase;
            ModeloTextBox.Text = obj.Modelo;
            ObservacionesTextBox.Text = obj.Observaciones;
            PersonaIdTextBox.Text = obj.PersonaId.ToString();
            CodigoExternoTextBox.Text = obj.CodigoExterno.ToString();





        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al obetener los datos de la mascota seleccionada: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-3 mb-2";
            return;
        }
    }

    protected void BtnGuardar_Click(object sender, EventArgs e)
    {
        try
        {

            int vehiculoId = Convert.ToInt32(VehiculoIdHiddenField.Value);
            Vehiculo obj = new Vehiculo();

            obj.Placa = PlacaTextBox.Text.Trim();
            obj.Color = ColorTextBox.Text.Trim();
            obj.Marca = MarcaTextBox.Text.Trim();
            obj.Clase = ClaseTextBox.Text.Trim();
            obj.Modelo = ModeloTextBox.Text.Trim();
            obj.Observaciones = ObservacionesTextBox.Text.Trim();
            obj.PersonaId = Convert.ToInt32(PersonaIdTextBox.Text);
            
            obj.CodigoExterno = Convert.ToInt32(CodigoExternoTextBox.Text);
            obj.AutoId = vehiculoId;

            if (vehiculoId == 0)

                VehiculoBRL.InsertarVehiculo(obj);

            else
                VehiculoBRL.UpdateVehiculo(obj);
        }

        catch (Exception ex)
        {


            MsgLabel.Text = "Ocurrio un error al guardar los datos de la mascota seleccionada: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-3 mb-2";
            return;

        }

        Response.Redirect("ListaVehiculos.aspx");

    }
}