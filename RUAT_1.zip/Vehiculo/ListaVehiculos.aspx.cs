﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vehiculo_ListaVehiculos : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (IsPostBack)

            return;

        CargarLista();



    }
    private void CargarLista()
    {
        MsgPanel.Visible = false;
        try
        {
            GridVehiculos.DataSource = VehiculoBRL.GetVehiculos();
            GridVehiculos.DataBind();
        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al cargar la lista de vehiculos: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
            return;
        }

    }

    protected void GridVehiculos_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        MsgPanel.Visible = false;
        int vehiculoId = 0;
        try
        {
            vehiculoId = Convert.ToInt32(e.CommandArgument);
        }
        catch
        {
            MsgLabel.Text = "NO se pudo obtener el identificador del auto";
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

            return;
        }

        if (vehiculoId <= 0)
            return;



        if (e.CommandName == "Editar")
        {
            Response.Redirect("FormularioVehiculo.aspx?id=" + vehiculoId.ToString());
        }
        if (e.CommandName == "Eliminar")
        {
            try
            {

                VehiculoBRL.DeleteVehiculo(vehiculoId);

                CargarLista();


                MsgLabel.Text = "El vehiculo fue eliminado correctamente";
                MsgPanel.Visible = true;
                MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

            }
            catch (Exception ex)
            {
                MsgLabel.Text = "Ocurrio un error al eliminar el vehiculo seleccionado: " + ex.Message;
                MsgPanel.Visible = true;
                MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
                return;
            }
        }


    }
    protected void SearchButton_Click(object sender, EventArgs e)
    {

        MsgPanel.Visible = false;
        try
        {
            GridVehiculos.DataSource = VehiculoBRL.GetVehiculosBySearch(SearchTextBox.Text.Trim());
            GridVehiculos.DataBind();
        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al cargar la lista de vehiculos: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
            return;
        }
    }


}
