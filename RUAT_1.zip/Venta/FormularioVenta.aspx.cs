﻿using BRL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Venta_FormularioVenta : System.Web.UI.Page
{
    public Dictionary<int, DetalleVenta> Detalle
    {
        set { ViewState["Detalle"] = value; }
        get
        {
            Dictionary<int, DetalleVenta> detalle = null;
            if (ViewState["Detalle"] == null)
            {
                detalle = new Dictionary<int, DetalleVenta>();
                ViewState["Detalle"] = detalle;
            }
            else
            {
                try
                {
                    detalle = ViewState["Detalle"] as Dictionary<int, DetalleVenta>;
                    //detalle = (Dictionary<int, DetalleVenta>) ViewState["Detalle"];
                }
                catch (Exception ex)
                {
                    detalle = new Dictionary<int, DetalleVenta>();
                    ViewState["Detalle"] = detalle;
                }
            }
            return detalle;
        }
    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
            return;

        try
        {
            List<Vehiculo> vehiculos = VehiculoBRL.GetVehiculos();
            vehiculos.Insert(0, new Vehiculo()
            {
                VehiculoId = 0,
                Nombre = "-- Seleccione un Producto --"
            });

            VehiculosComboBox.DataSource = vehiculos;
            VehiculosComboBox.DataBind();
        }
        catch (Exception ex)
        {

        }
    }

    protected void GuardarBtn_Click(object sender, EventArgs e)
    {
        try
        {
            string razonSocial = RazonSocialTextBox.Text.Trim();
            if (string.IsNullOrEmpty(razonSocial))
                razonSocial = "SIN NOMBRE";

            string nit = NitTextBox.Text.Trim();
            if (string.IsNullOrEmpty(nit))
                nit = "0";

            List<DetalleVenta> detalle = Detalle.Values.ToList<DetalleVenta>();
            decimal total = detalle.Sum(o => o.Subtotal);
            int userId = Convert.ToInt32(Session["UserId"]);

            Venta obj = new Venta()
            {
                RazonSocial = razonSocial,
                Nit = nit,
                Total = total,
                PersonaId = 0,
                UsuarioId = userId,
                Fecha = DateTime.Now
            };

            VentaBRL.InsertVenta(obj, detalle);
        }
        catch (Exception ex)
        {
            return;
        }

        Response.Redirect("ListaVentas.aspx");

    }

    protected void DetalleGrid_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void AgregarVehiculo_Click(object sender, EventArgs e)
    {
        try
        {
            Dictionary<int, DetalleVenta> detalle = this.Detalle;
            int vehiculoId = Convert.ToInt32(VehiculosComboBox.SelectedValue);
            int cantidad = Convert.ToInt32(CantidadTextBox.Text.Trim());

            DetalleVenta objDetalle = null;
            if (detalle.ContainsKey(vehiculoId))
            {
                objDetalle = detalle[vehiculoId];
                objDetalle.cantidad = objDetalle.cantidad + cantidad;
                objDetalle.Subtotal = objDetalle.precioUnitario * objDetalle.cantidad;

            }
            else
            {
               Vehiculo objProducto = VehiculoBRL.GetVehiculoById(vehiculoId);
                objDetalle = new DetalleVenta()
                {
                    vehiculoId = vehiculoId,
                    Nombre = objProducto.Nombre,
                    precioUnitario = objProducto.Precio,
                    cantidad = cantidad,
                    Subtotal = cantidad * objProducto.Precio
                };
                detalle.Add(vehiculoId, objDetalle);

            }

            this.Detalle = detalle;

            DetalleGrid.DataSource = detalle.Values.ToList<DetalleVenta>();
            DetalleGrid.DataBind();

            VehiculosComboBox.ClearSelection();
            CantidadTextBox.Text = "";
            GuardarBtn.Visible = true;

        }
        catch (Exception ex)
        {

        }
    }
}