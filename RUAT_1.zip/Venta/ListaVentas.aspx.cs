﻿using BRL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Venta_ListaVentas : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (IsPostBack)

            return;

        CargarLista();



    }
    private void CargarLista()
    {
        MsgPanel.Visible = false;
        try
        {
            GridVentas.DataSource = VentaBRL.GetVentas();
            GridVentas.DataBind();
        }
        catch (Exception ex)
        {
            MsgLabel.Text = "Ocurrio un error al cargar la lista de ventas: " + ex.Message;
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
            return;
        }

    }

    protected void GridVentas_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        MsgPanel.Visible = false;
        int ventasId = 0;
        try
        {
            ventasId = Convert.ToInt32(e.CommandArgument);
        }
        catch
        {
            MsgLabel.Text = "NO se pudo obtener el identificador de la venta";
            MsgPanel.Visible = true;
            MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

            return;
        }

        if (ventasId <= 0)
            return;



        if (e.CommandName == "Editar")
        {
            Response.Redirect("FormularioVehiculo.aspx?id=" + ventasId.ToString());
        }
        //if (e.CommandName == "Eliminar")
        //{
        //    try
        //    {

        //        VentaBRL.(ventasId);

        //        CargarLista();


        //        MsgLabel.Text = "El vehiculo fue eliminado correctamente";
        //        MsgPanel.Visible = true;
        //        MsgPanel.CssClass = "alert alert-success mt-2 mb-2";

        //    }
        //    catch (Exception ex)
        //    {
        //        MsgLabel.Text = "Ocurrio un error al eliminar el vehiculo seleccionado: " + ex.Message;
        //        MsgPanel.Visible = true;
        //        MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
        //        return;
        //    }
        //}


    }
    //protected void SearchButton_Click(object sender, EventArgs e)
    //{

    //    MsgPanel.Visible = false;
    //    try
    //    {
    //        GridVentas.DataSource = VentaBRL.GetVentasBySearch(SearchTextBox.Text.Trim());
    //        GridVehiculos.DataBind();
    //    }
    //    catch (Exception ex)
    //    {
    //        MsgLabel.Text = "Ocurrio un error al cargar la lista de vehiculos: " + ex.Message;
    //        MsgPanel.Visible = true;
    //        MsgPanel.CssClass = "alert alert-success mt-2 mb-2";
    //        return;
    //    }
    //}

}